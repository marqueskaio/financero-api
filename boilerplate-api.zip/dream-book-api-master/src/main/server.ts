import app from './config/app'

app.listen(3333)
console.log('Server running on port 3333')

// sequelize.authenticate().then(async () => {
//   await UserSequelize.sync({})
  // app.listen(3333)
  // console.log('Server running on port 3333')
// })
