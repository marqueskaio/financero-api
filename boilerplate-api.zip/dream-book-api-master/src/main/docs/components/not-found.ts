export const notFound = {
  description: 'APi Não encontrada'
}
