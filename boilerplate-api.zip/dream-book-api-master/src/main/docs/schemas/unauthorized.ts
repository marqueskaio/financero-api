export const unauthorizedSchema = {
  type: 'object',
  properties: {
    error: {
      type: 'string'
    }
  }
}
