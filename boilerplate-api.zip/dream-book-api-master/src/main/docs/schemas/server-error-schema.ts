export const serverErrorSchema = {
  type: 'object',
  properties: {
    error: {
      type: 'string'
    }
  }
}
