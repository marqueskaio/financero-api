export const throwException = (): never => {
  throw new Error()
}