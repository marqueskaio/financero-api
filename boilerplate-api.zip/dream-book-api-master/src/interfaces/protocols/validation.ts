export interface Validation {
  validate: (input: any) => Error | null
}
