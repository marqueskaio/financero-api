export interface SignInParamsInterface {
  email: string
  password: string
}