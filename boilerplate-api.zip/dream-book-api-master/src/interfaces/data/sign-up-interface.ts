export interface SignUpParamsInterface {
  email: string
  name: string
  password: string
}